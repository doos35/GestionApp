
import { MaterialItem } from '@/types';

class DatabaseService {
  private db: IDBDatabase | null = null;
  private readonly DB_NAME = 'materialManager';
  private readonly DB_VERSION = 1;
  
  constructor() {
    this.initDB();
  }
  
  private initDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      if (this.db) {
        resolve(this.db);
        return;
      }
      
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
      
      request.onerror = (event) => {
        console.error('IndexedDB error:', event);
        reject(new Error('Failed to open database'));
      };
      
      request.onsuccess = (event) => {
        this.db = (event.target as IDBRequest).result;
        resolve(this.db);
      };
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBRequest).result;
        
        // Create object stores
        if (!db.objectStoreNames.contains('materials')) {
          const store = db.createObjectStore('materials', { keyPath: 'id' });
          store.createIndex('type', 'type', { unique: false });
          store.createIndex('designation', 'designation', { unique: false });
          store.createIndex('parentId', 'location.parentId', { unique: false });
        }
        
        if (!db.objectStoreNames.contains('plans')) {
          db.createObjectStore('plans', { keyPath: 'id' });
        }
      };
    });
  }
  
  // Materials CRUD operations
  async getAllMaterials(): Promise<MaterialItem[]> {
    try {
      const db = await this.initDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(['materials'], 'readonly');
        const store = transaction.objectStore('materials');
        const request = store.getAll();
        
        request.onsuccess = () => {
          resolve(request.result);
        };
        
        request.onerror = (event) => {
          reject(new Error('Failed to get materials'));
        };
      });
    } catch (error) {
      console.error('Error getting materials:', error);
      return [];
    }
  }
  
  async getMaterialById(id: string): Promise<MaterialItem | null> {
    try {
      const db = await this.initDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(['materials'], 'readonly');
        const store = transaction.objectStore('materials');
        const request = store.get(id);
        
        request.onsuccess = () => {
          resolve(request.result || null);
        };
        
        request.onerror = (event) => {
          reject(new Error(`Failed to get material with id ${id}`));
        };
      });
    } catch (error) {
      console.error(`Error getting material with id ${id}:`, error);
      return null;
    }
  }
  
  async addMaterial(material: MaterialItem): Promise<string> {
    try {
      const db = await this.initDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(['materials'], 'readwrite');
        const store = transaction.objectStore('materials');
        const request = store.add(material);
        
        request.onsuccess = () => {
          resolve(material.id);
        };
        
        request.onerror = (event) => {
          reject(new Error('Failed to add material'));
        };
      });
    } catch (error) {
      console.error('Error adding material:', error);
      throw error;
    }
  }
  
  async updateMaterial(material: MaterialItem): Promise<void> {
    try {
      const db = await this.initDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(['materials'], 'readwrite');
        const store = transaction.objectStore('materials');
        const request = store.put(material);
        
        request.onsuccess = () => {
          resolve();
        };
        
        request.onerror = (event) => {
          reject(new Error(`Failed to update material with id ${material.id}`));
        };
      });
    } catch (error) {
      console.error(`Error updating material with id ${material.id}:`, error);
      throw error;
    }
  }
  
  async deleteMaterial(id: string): Promise<void> {
    try {
      const db = await this.initDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(['materials'], 'readwrite');
        const store = transaction.objectStore('materials');
        const request = store.delete(id);
        
        request.onsuccess = () => {
          resolve();
        };
        
        request.onerror = (event) => {
          reject(new Error(`Failed to delete material with id ${id}`));
        };
      });
    } catch (error) {
      console.error(`Error deleting material with id ${id}:`, error);
      throw error;
    }
  }
  
  // Data export
  async exportData(): Promise<string> {
    try {
      const materials = await this.getAllMaterials();
      return JSON.stringify(materials);
    } catch (error) {
      console.error('Error exporting data:', error);
      throw error;
    }
  }
  
  // Import data - be careful with this as it can overwrite existing data
  async importData(jsonData: string): Promise<void> {
    try {
      const materials = JSON.parse(jsonData) as MaterialItem[];
      const db = await this.initDB();
      
      const transaction = db.transaction(['materials'], 'readwrite');
      const store = transaction.objectStore('materials');
      
      // Clear existing data
      store.clear();
      
      // Add new data
      for (const material of materials) {
        store.add(material);
      }
      
      return new Promise((resolve, reject) => {
        transaction.oncomplete = () => {
          resolve();
        };
        
        transaction.onerror = (event) => {
          reject(new Error('Failed to import data'));
        };
      });
    } catch (error) {
      console.error('Error importing data:', error);
      throw error;
    }
  }
  
  // Add some test data to get started
  async populateTestData(): Promise<void> {
    const testItems: MaterialItem[] = [
      {
        id: "EQUIP-001",
        type: "equipment",
        designation: "Alimentation 48V",
        physicalAttributes: { width: "19\"", height: "2U", weight: 5.2 },
        location: { parentId: null, coordinates: { x: 120, y: 45 } },
        qrData: { content: "MAT:EQUIP-001|LOC:null|TYPE:equipment" }
      },
      {
        id: "EQUIP-002",
        type: "equipment",
        designation: "Switch Cisco 3750",
        physicalAttributes: { width: "19\"", height: "1U", weight: 3.8 },
        location: { parentId: null, coordinates: { x: 150, y: 120 } },
        qrData: { content: "MAT:EQUIP-002|LOC:null|TYPE:equipment" }
      },
      {
        id: "CONT-001",
        type: "container",
        designation: "Rack Serveurs 42U",
        physicalAttributes: { width: "60cm", height: "42U", weight: 120 },
        location: { parentId: null, coordinates: { x: 300, y: 200 } },
        qrData: { content: "MAT:CONT-001|LOC:null|TYPE:container" }
      },
      {
        id: "CABLE-001",
        type: "cable",
        designation: "Câble réseau Cat6 2m",
        physicalAttributes: { weight: 0.2 },
        location: { parentId: "CONT-001", coordinates: { x: 10, y: 30 } },
        qrData: { content: "MAT:CABLE-001|LOC:CONT-001|TYPE:cable" }
      }
    ];
    
    for (const item of testItems) {
      try {
        await this.addMaterial(item);
      } catch (error) {
        console.log(`Item ${item.id} already exists, updating...`);
        await this.updateMaterial(item);
      }
    }
  }
}

// Create a singleton instance
const db = new DatabaseService();
export default db;
