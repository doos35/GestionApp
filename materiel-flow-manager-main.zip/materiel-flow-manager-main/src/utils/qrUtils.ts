
import { QRCodeData } from '@/types';

export const isValidQR = (content: string): boolean => {
  return content.startsWith('MAT:') && content.includes('TYPE:');
};

export const processQR = (data: string): QRCodeData => {
  const parts = data.split('|');
  const idPart = parts.find(p => p.startsWith('MAT:'))?.split(':')[1] || '';
  const locationPart = parts.find(p => p.startsWith('LOC:'))?.split(':')[1] || '';
  const typePart = parts.find(p => p.startsWith('TYPE:'))?.split(':')[1] || '';
  
  return {
    id: idPart,
    location: locationPart === 'null' ? '' : locationPart,
    itemType: typePart
  };
};

export const generateQRContent = (
  id: string, 
  parentId: string | null, 
  type: 'equipment' | 'container' | 'cable'
): string => {
  return `MAT:${id}|LOC:${parentId || 'null'}|TYPE:${type}`;
};
