
import { MaterialItem } from '@/types';
import * as XLSX from 'xlsx';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

// Export to Excel
export const exportToExcel = (materials: MaterialItem[]): void => {
  const data = materials.map(material => ({
    ID: material.id,
    Type: material.type,
    Designation: material.designation,
    Width: material.physicalAttributes.width || '',
    Height: material.physicalAttributes.height || '',
    Weight: material.physicalAttributes.weight || '',
    ParentID: material.location.parentId || '',
    X: material.location.coordinates.x,
    Y: material.location.coordinates.y,
    QRContent: material.qrData.content,
    LastScan: material.qrData.lastScan ? material.qrData.lastScan.toLocaleString() : '',
    Expected: material.inventoryData?.expected ? 'Oui' : 'Non',
    Checked: material.inventoryData?.checked ? 'Oui' : 'Non',
    Comment: material.inventoryData?.comment || ''
  }));
  
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Materials');
  
  // Generate file name with date
  const date = new Date().toISOString().split('T')[0];
  const fileName = `export_materials_${date}.xlsx`;
  
  // Export to file
  XLSX.writeFile(workbook, fileName);
};

// Export inventory list to Excel
export const exportInventoryToExcel = (materials: MaterialItem[]): void => {
  // Filter materials with inventory data
  const data = materials
    .filter(material => material.inventoryData)
    .map(material => ({
      ID: material.id,
      Designation: material.designation,
      Type: material.type,
      Expected: material.inventoryData?.expected ? 'Oui' : 'Non',
      Checked: material.inventoryData?.checked ? 'Oui' : 'Non',
      Status: material.inventoryData?.checked ? 'Trouvé' : 'Non vérifié',
      Comment: material.inventoryData?.comment || ''
    }));
  
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventory');
  
  // Generate file name with date
  const date = new Date().toISOString().split('T')[0];
  const fileName = `inventory_checklist_${date}.xlsx`;
  
  // Export to file
  XLSX.writeFile(workbook, fileName);
};

// Export labels to PDF
export const exportLabelsToPDF = async (materials: MaterialItem[]): Promise<Uint8Array> => {
  const pdfDoc = await PDFDocument.create();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  
  // Create a new page for each material
  for (const material of materials) {
    const page = pdfDoc.addPage([300, 150]);
    const { width, height } = page.getSize();
    
    // Draw border
    page.drawRectangle({
      x: 5,
      y: 5,
      width: width - 10,
      height: height - 10,
      borderColor: rgb(0, 0, 0),
      borderWidth: 1,
    });
    
    // Draw title
    page.drawText('ÉTIQUETTE MATÉRIEL', {
      x: 50,
      y: height - 20,
      size: 12,
      font: boldFont,
    });
    
    // Draw material info
    page.drawText(`ID: ${material.id}`, {
      x: 10,
      y: height - 40,
      size: 10,
      font: font,
    });
    
    page.drawText(`Type: ${material.type}`, {
      x: 10,
      y: height - 55,
      size: 10,
      font: font,
    });
    
    page.drawText(`Désignation: ${material.designation}`, {
      x: 10,
      y: height - 70,
      size: 10,
      font: font,
    });
    
    // Draw placeholder for QR code
    page.drawRectangle({
      x: width - 80,
      y: height - 80,
      width: 70,
      height: 70,
      borderColor: rgb(0, 0, 0),
      borderWidth: 1,
    });
    
    page.drawText('QR Code', {
      x: width - 65,
      y: height - 45,
      size: 8,
      font: font,
    });
  }
  
  return pdfDoc.save();
};

// Export functions
export const downloadPDF = async (materials: MaterialItem[]): Promise<void> => {
  const pdfBytes = await exportLabelsToPDF(materials);
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `labels_${new Date().toISOString().split('T')[0]}.pdf`;
  link.click();
  
  URL.revokeObjectURL(url);
};
