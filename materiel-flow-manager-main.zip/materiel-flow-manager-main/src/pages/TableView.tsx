
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import TableViewComponent from '@/components/TableView';
import MaterialForm from '@/components/MaterialForm';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';
import { MaterialItem } from '@/types';
import { Form } from '@/components/ui/form';
import { exportToExcel } from '@/utils/exportUtils';
import { FileUp, FileDown, FileText, Plus } from 'lucide-react';

const TableViewPage = () => {
  const { 
    materials, 
    loading, 
    addMaterial, 
    updateMaterial, 
    deleteMaterial, 
    exportToJson 
  } = useApp();
  const [editMaterial, setEditMaterial] = useState<MaterialItem | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  const handleEdit = (material: MaterialItem) => {
    setEditMaterial(material);
    setIsEditDialogOpen(true);
  };
  
  const handleDelete = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cet élément ?')) {
      deleteMaterial(id);
    }
  };
  
  const handleExportExcel = () => {
    exportToExcel(materials);
  };

  const handleAddMaterial = (data: Omit<MaterialItem, 'id' | 'qrData'>) => {
    addMaterial(data);
  };

  const handleUpdateMaterial = (data: Omit<MaterialItem, 'id' | 'qrData'>) => {
    if (editMaterial) {
      updateMaterial({
        ...editMaterial,
        ...data,
      });
    }
  };

  const handleNestMaterial = (childId: string, parentId: string) => {
    const material = materials.find(m => m.id === childId);
    if (material) {
      updateMaterial({
        ...material,
        location: {
          ...material.location,
          parentId: parentId
        }
      });
    }
  };

  const handleUnnestMaterial = (childId: string) => {
    const material = materials.find(m => m.id === childId);
    if (material) {
      updateMaterial({
        ...material,
        location: {
          ...material.location,
          parentId: null
        }
      });
    }
  };
  
  return (
    <Layout>
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 dark:border-white"></div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Button onClick={() => setIsAddDialogOpen(true)} variant="default">
              <Plus size={16} className="mr-2" />
              Ajouter un bloc
            </Button>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={handleExportExcel}>
                <FileText size={16} className="mr-2" />
                Exporter Excel
              </Button>
              <Button variant="outline" onClick={exportToJson}>
                <FileDown size={16} className="mr-2" />
                Exporter JSON
              </Button>
            </div>
          </div>
          
          <TableViewComponent 
            materials={materials} 
            onEdit={handleEdit} 
            onDelete={handleDelete}
            onNestMaterial={handleNestMaterial}
            onUnnestMaterial={handleUnnestMaterial}
          />
          
          <MaterialForm
            isOpen={isAddDialogOpen}
            onClose={() => setIsAddDialogOpen(false)}
            onSubmit={handleAddMaterial}
          />
          
          <MaterialForm
            isOpen={isEditDialogOpen}
            onClose={() => setIsEditDialogOpen(false)}
            onSubmit={handleUpdateMaterial}
            initialData={editMaterial || undefined}
          />
        </div>
      )}
    </Layout>
  );
};

export default TableViewPage;
