
import React from 'react';
import Layout from '@/components/Layout';
import DashboardContent from '@/components/Dashboard';
import { useApp } from '@/context/AppContext';

const DashboardPage = () => {
  const { loading } = useApp();
  
  return (
    <Layout>
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 dark:border-white"></div>
        </div>
      ) : (
        <DashboardContent />
      )}
    </Layout>
  );
};

export default DashboardPage;
