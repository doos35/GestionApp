
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import QRCodeScanner from '@/components/QRCodeScanner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/context/AppContext';
import { QRCodeData } from '@/types';
import { exportInventoryToExcel } from '@/utils/exportUtils';
import { CheckSquare, QrCode, FileText } from 'lucide-react';

const InventoryPage = () => {
  const { materials, loading, markAsFound } = useApp();
  const [isScanMode, setIsScanMode] = useState(false);
  
  // Filter materials with inventory data
  const inventoryItems = materials.filter(material => material.inventoryData?.expected);
  const checkedCount = inventoryItems.filter(material => material.inventoryData?.checked).length;
  const progress = inventoryItems.length > 0 
    ? Math.round((checkedCount / inventoryItems.length) * 100)
    : 0;
  
  const handleScan = (data: QRCodeData) => {
    markAsFound(data.id);
  };
  
  const handleExport = () => {
    exportInventoryToExcel(materials);
  };
  
  return (
    <Layout>
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 dark:border-white"></div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Inventaire</h2>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setIsScanMode(!isScanMode)}>
                <QrCode size={16} className="mr-2" />
                {isScanMode ? 'Fermer Scanner' : 'Scanner QR'}
              </Button>
              <Button variant="outline" onClick={handleExport}>
                <FileText size={16} className="mr-2" />
                Exporter
              </Button>
            </div>
          </div>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Progression de l'inventaire</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Progress value={progress} className="h-2" />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>{checkedCount} vérifiés</span>
                  <span>{progress}%</span>
                  <span>{inventoryItems.length} total</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {isScanMode ? (
            <QRCodeScanner onScan={handleScan} visualFeedback="glow" />
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Liste d'inventaire</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">ID</TableHead>
                      <TableHead>Désignation</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="w-[100px]">Statut</TableHead>
                      <TableHead className="w-[150px]">Dernier scan</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {inventoryItems.length > 0 ? (
                      inventoryItems.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-mono text-xs">{item.id}</TableCell>
                          <TableCell>{item.designation}</TableCell>
                          <TableCell>{item.type}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium
                              ${item.inventoryData?.checked 
                                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                                : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100'
                              }`}
                            >
                              {item.inventoryData?.checked ? 'Trouvé' : 'À vérifier'}
                            </span>
                          </TableCell>
                          <TableCell>
                            {item.qrData.lastScan 
                              ? new Date(item.qrData.lastScan).toLocaleString() 
                              : 'Jamais'}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                          Aucun élément dans l'inventaire
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </Layout>
  );
};

export default InventoryPage;
