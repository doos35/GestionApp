
import React, { useState } from 'react';
import Layout from '@/components/Layout';
import QRCodeGenerator from '@/components/QRCodeGenerator';
import QRCodeScanner from '@/components/QRCodeScanner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useApp } from '@/context/AppContext';
import { QRCodeData } from '@/types';
import { downloadPDF } from '@/utils/exportUtils';
import { Printer, QrCode } from 'lucide-react';

const QRCodesPage = () => {
  const { materials, loading, markAsFound } = useApp();
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([]);
  
  const handleScan = (data: QRCodeData) => {
    markAsFound(data.id);
  };
  
  const toggleMaterialSelection = (id: string) => {
    setSelectedMaterials(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id) 
        : [...prev, id]
    );
  };
  
  const handleExportPDF = async () => {
    const selectedItems = materials.filter(m => selectedMaterials.includes(m.id));
    if (selectedItems.length === 0) {
      alert('Veuillez sélectionner au moins un élément.');
      return;
    }
    
    await downloadPDF(selectedItems);
  };
  
  return (
    <Layout>
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 dark:border-white"></div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">QR Codes</h2>
            <Button onClick={handleExportPDF} disabled={selectedMaterials.length === 0}>
              <Printer size={16} className="mr-2" />
              Exporter étiquettes PDF
            </Button>
          </div>
          
          <Tabs defaultValue="generator">
            <TabsList>
              <TabsTrigger value="generator">Générateur</TabsTrigger>
              <TabsTrigger value="scanner">Scanner</TabsTrigger>
              <TabsTrigger value="batch">Étiquettes multiples</TabsTrigger>
            </TabsList>
            
            <TabsContent value="generator" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Générateur de QR Code</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center">
                    <QRCodeGenerator />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="scanner">
              <Card>
                <CardHeader>
                  <CardTitle>Scanner de QR Code</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center">
                    <QRCodeScanner onScan={handleScan} />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="batch">
              <Card>
                <CardHeader>
                  <CardTitle>Créer plusieurs étiquettes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {materials.map(material => (
                        <div 
                          key={material.id}
                          className={`p-4 border rounded-md cursor-pointer transition-colors
                            ${selectedMaterials.includes(material.id) 
                              ? 'bg-blue-50 border-blue-500 dark:bg-blue-900/30 dark:border-blue-500' 
                              : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                            }`}
                          onClick={() => toggleMaterialSelection(material.id)}
                        >
                          <div className="flex items-start">
                            <div 
                              className={`w-4 h-4 mr-2 mt-1 rounded border flex-shrink-0
                                ${selectedMaterials.includes(material.id) 
                                  ? 'bg-blue-500 border-blue-500' 
                                  : 'border-gray-300 dark:border-gray-600'
                                }`}
                            >
                              {selectedMaterials.includes(material.id) && (
                                <QrCode className="text-white w-3 h-3 m-auto" />
                              )}
                            </div>
                            <div>
                              <div className="font-medium">{material.designation}</div>
                              <div className="text-xs text-gray-500">{material.id}</div>
                              <div className="text-xs mt-1 capitalize">{material.type}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex justify-end">
                      <Button 
                        onClick={handleExportPDF}
                        disabled={selectedMaterials.length === 0}
                      >
                        <Printer size={16} className="mr-2" />
                        Exporter {selectedMaterials.length} étiquette(s)
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}
    </Layout>
  );
};

export default QRCodesPage;
