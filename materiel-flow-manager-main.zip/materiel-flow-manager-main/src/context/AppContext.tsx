
import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { MaterialItem } from '@/types';
import db from '@/services/db';
import { generateQRContent } from '@/utils/qrUtils';
import { toast } from '@/components/ui/use-toast';

interface AppContextType {
  materials: MaterialItem[];
  loading: boolean;
  addMaterial: (material: Omit<MaterialItem, 'id' | 'qrData'>) => Promise<void>;
  updateMaterial: (material: MaterialItem) => Promise<void>;
  deleteMaterial: (id: string) => Promise<void>;
  moveMaterial: (id: string, newX: number, newY: number) => Promise<void>;
  markAsFound: (id: string) => Promise<void>;
  importInventoryData: (data: any[]) => Promise<void>;
  exportToJson: () => Promise<void>;
  importFromJson: (jsonString: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Initial data load
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const items = await db.getAllMaterials();
        
        if (items.length === 0) {
          // Populate test data if no items exist
          await db.populateTestData();
          const testItems = await db.getAllMaterials();
          setMaterials(testItems);
        } else {
          setMaterials(items);
        }
      } catch (error) {
        console.error('Error loading materials:', error);
        toast({
          title: 'Erreur',
          description: 'Impossible de charger les données du matériel.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);
  
  const addMaterial = async (materialData: Omit<MaterialItem, 'id' | 'qrData'>) => {
    try {
      const id = `${materialData.type.toUpperCase()}-${uuidv4().slice(0, 8)}`;
      const qrContent = generateQRContent(id, materialData.location.parentId, materialData.type);
      
      const newMaterial: MaterialItem = {
        ...materialData,
        id,
        qrData: {
          content: qrContent,
        }
      };
      
      await db.addMaterial(newMaterial);
      setMaterials(prev => [...prev, newMaterial]);
      
      toast({
        title: 'Succès',
        description: `${materialData.designation} a été ajouté.`,
      });
    } catch (error) {
      console.error('Error adding material:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible d\'ajouter le matériel.',
        variant: 'destructive',
      });
    }
  };
  
  const updateMaterial = async (material: MaterialItem) => {
    try {
      await db.updateMaterial(material);
      setMaterials(prev => 
        prev.map(item => item.id === material.id ? material : item)
      );
      
      toast({
        title: 'Succès',
        description: `${material.designation} a été mis à jour.`,
      });
    } catch (error) {
      console.error('Error updating material:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de mettre à jour le matériel.',
        variant: 'destructive',
      });
    }
  };
  
  const deleteMaterial = async (id: string) => {
    try {
      await db.deleteMaterial(id);
      setMaterials(prev => prev.filter(item => item.id !== id));
      
      toast({
        title: 'Succès',
        description: 'Matériel supprimé avec succès.',
      });
    } catch (error) {
      console.error('Error deleting material:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de supprimer le matériel.',
        variant: 'destructive',
      });
    }
  };
  
  const moveMaterial = async (id: string, newX: number, newY: number) => {
    try {
      const material = materials.find(m => m.id === id);
      if (!material) return;
      
      const updatedMaterial = {
        ...material,
        location: {
          ...material.location,
          coordinates: { x: newX, y: newY }
        }
      };
      
      await db.updateMaterial(updatedMaterial);
      setMaterials(prev => 
        prev.map(item => item.id === id ? updatedMaterial : item)
      );
    } catch (error) {
      console.error('Error moving material:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de déplacer le matériel.',
        variant: 'destructive',
      });
    }
  };
  
  const markAsFound = async (id: string) => {
    try {
      const material = materials.find(m => m.id === id);
      if (!material) {
        toast({
          title: 'Attention',
          description: `Matériel avec ID ${id} non trouvé dans l'inventaire.`,
          variant: 'destructive',
        });
        return;
      }
      
      const updatedMaterial = {
        ...material,
        qrData: {
          ...material.qrData,
          lastScan: new Date(),
        },
        inventoryData: {
          ...material.inventoryData,
          checked: true,
        }
      };
      
      await db.updateMaterial(updatedMaterial);
      setMaterials(prev => 
        prev.map(item => item.id === id ? updatedMaterial : item)
      );
      
      toast({
        title: 'Scan réussi',
        description: `${material.designation} a été trouvé et marqué dans l'inventaire.`,
      });
    } catch (error) {
      console.error('Error marking material as found:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de mettre à jour le statut du matériel.',
        variant: 'destructive',
      });
    }
  };
  
  const importInventoryData = async (data: any[]) => {
    try {
      let updatedCount = 0;
      
      for (const item of data) {
        if (!item.id) continue;
        
        const existingMaterial = materials.find(m => m.id === item.id);
        if (!existingMaterial) continue;
        
        const updatedMaterial = {
          ...existingMaterial,
          inventoryData: {
            expected: item.expected === 'Oui' || item.expected === true,
            checked: existingMaterial.inventoryData?.checked || false,
            comment: item.comment || existingMaterial.inventoryData?.comment || '',
          }
        };
        
        await db.updateMaterial(updatedMaterial);
        updatedCount++;
      }
      
      // Refresh materials
      const refreshedMaterials = await db.getAllMaterials();
      setMaterials(refreshedMaterials);
      
      toast({
        title: 'Import réussi',
        description: `${updatedCount} éléments ont été mis à jour dans l'inventaire.`,
      });
    } catch (error) {
      console.error('Error importing inventory data:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible d\'importer les données d\'inventaire.',
        variant: 'destructive',
      });
    }
  };
  
  const exportToJson = async () => {
    try {
      const jsonData = await db.exportData();
      
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `materials_export_${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      
      URL.revokeObjectURL(url);
      
      toast({
        title: 'Export réussi',
        description: 'Les données ont été exportées au format JSON.',
      });
    } catch (error) {
      console.error('Error exporting data:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible d\'exporter les données.',
        variant: 'destructive',
      });
    }
  };
  
  const importFromJson = async (jsonString: string) => {
    try {
      await db.importData(jsonString);
      
      // Refresh materials
      const refreshedMaterials = await db.getAllMaterials();
      setMaterials(refreshedMaterials);
      
      toast({
        title: 'Import réussi',
        description: 'Les données ont été importées avec succès.',
      });
    } catch (error) {
      console.error('Error importing data:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible d\'importer les données. Vérifiez le format du fichier.',
        variant: 'destructive',
      });
    }
  };
  
  const contextValue: AppContextType = {
    materials,
    loading,
    addMaterial,
    updateMaterial,
    deleteMaterial,
    moveMaterial,
    markAsFound,
    importInventoryData,
    exportToJson,
    importFromJson,
  };
  
  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
