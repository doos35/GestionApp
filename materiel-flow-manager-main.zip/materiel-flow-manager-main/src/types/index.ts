
// Core data models
export interface MaterialItem {
  id: string; // UUID v4
  type: 'equipment' | 'container' | 'cable';
  designation: string;
  physicalAttributes: {
    width?: string; // "19\""
    height?: string; // "2U"
    weight?: number; // kg
  };
  location: {
    parentId: string | null;
    coordinates: { x: number; y: number };
    backgroundPlanRef?: string;
  };
  qrData: {
    content: string;
    lastScan?: Date;
  };
  inventoryData?: {
    expected: boolean;
    checked: boolean;
    comment: string;
  };
}

// DND Configuration
export interface DNDConfig {
  snapTolerance: number;
  containment: string;
  collisionDetection: {
    type: string;
    modifiers: string[];
  };
}

// QR Code Data Structure
export interface QRCodeData {
  id: string;
  location: string;
  itemType: string;
}

// Inventory Data Import Format
export interface InventoryImport {
  id: string;
  expected: boolean;
  comment?: string;
}

// Background Plan Options
export interface BackgroundPlan {
  id: string;
  name: string;
  filePath: string;
  scale: number;
  dimensions: {
    width: number;
    height: number;
  };
}
