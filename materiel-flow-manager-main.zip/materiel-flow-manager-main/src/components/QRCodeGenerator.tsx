
import React, { useState, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MaterialItem } from '@/types';
import { toast } from '@/components/ui/use-toast';

interface QRCodeGeneratorProps {
  material?: MaterialItem;
}

const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ material }) => {
  const [qrData, setQrData] = useState(
    material 
      ? `MAT:${material.id}|LOC:${material.location.parentId || 'null'}|TYPE:${material.type}`
      : ''
  );
  
  const [qrSize, setQrSize] = useState(128);
  const [bgColor, setBgColor] = useState('#ffffff');
  const [fgColor, setFgColor] = useState('#000000');
  const qrRef = useRef<HTMLDivElement>(null);
  
  const handleDownload = () => {
    if (!qrRef.current) return;
    
    try {
      // Créer un canvas temporaire
      const canvas = document.createElement('canvas');
      const svg = qrRef.current.querySelector('svg');
      if (!svg) {
        throw new Error('SVG not found');
      }
      
      // Obtenir les dimensions
      const svgData = new XMLSerializer().serializeToString(svg);
      const img = new Image();
      
      img.onload = () => {
        canvas.width = qrSize;
        canvas.height = qrSize;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          throw new Error('Could not get canvas context');
        }
        
        // Dessiner l'image sur le canvas
        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, qrSize, qrSize);
        
        // Télécharger l'image
        const url = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = url;
        link.download = `qrcode-${material?.id || 'custom'}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        toast({
          title: "QR Code téléchargé",
          description: "Le QR code a été téléchargé avec succès.",
        });
      };
      
      img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
      
    } catch (error) {
      console.error('Error downloading QR code:', error);
      toast({
        title: "Erreur",
        description: "Impossible de télécharger le QR code.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Générateur de QR Code</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-center mb-4" ref={qrRef}>
          <div className="bg-white p-2 rounded-md inline-block">
            <QRCodeSVG
              value={qrData}
              size={qrSize}
              bgColor={bgColor}
              fgColor={fgColor}
              level="H"
              includeMargin={true}
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Contenu
          </label>
          <Input
            value={qrData}
            onChange={(e) => setQrData(e.target.value)}
            placeholder="Contenu du QR code"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Taille
            </label>
            <Select
              value={qrSize.toString()}
              onValueChange={(val) => setQrSize(parseInt(val))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Taille" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="128">Petit (128px)</SelectItem>
                <SelectItem value="256">Moyen (256px)</SelectItem>
                <SelectItem value="512">Grand (512px)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Couleur
            </label>
            <div className="flex space-x-2">
              <Input
                type="color"
                value={fgColor}
                onChange={(e) => setFgColor(e.target.value)}
                className="w-12 h-9 p-1"
              />
              <Input
                type="color"
                value={bgColor}
                onChange={(e) => setBgColor(e.target.value)}
                className="w-12 h-9 p-1"
              />
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleDownload} className="w-full">
          Télécharger
        </Button>
      </CardFooter>
    </Card>
  );
};

export default QRCodeGenerator;
