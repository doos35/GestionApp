
import React, { useState } from 'react';
import { Sun, Moon, Menu, X } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isMobile = useIsMobile();

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={cn('h-screen flex flex-col', darkMode ? 'dark' : '')}>
      <header className="bg-white dark:bg-gray-900 shadow-sm border-b">
        <div className="px-4 h-16 flex items-center justify-between">
          <div className="flex items-center">
            {isMobile && (
              <button 
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="mr-4 p-1"
              >
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            )}
            <h1 className="text-xl font-semibold">Gestionnaire de Matériel Industriel</h1>
          </div>
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </header>
      
      <div className="flex flex-1 overflow-hidden">
        <aside 
          className={cn(
            "bg-gray-50 dark:bg-gray-800 w-64 border-r flex-shrink-0 transition-all duration-300",
            isMobile ? "fixed h-full z-10" : "relative",
            isMobile && !sidebarOpen ? "-ml-64" : "ml-0"
          )}
        >
          <nav className="p-4 h-full">
            <ul className="space-y-2">
              <li>
                <a 
                  href="/" 
                  className="block px-4 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  Dashboard
                </a>
              </li>
              <li>
                <a 
                  href="/floor-plan" 
                  className="block px-4 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  Plan d'étage
                </a>
              </li>
              <li>
                <a 
                  href="/table-view" 
                  className="block px-4 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  Vue Tableau
                </a>
              </li>
              <li>
                <a 
                  href="/inventory" 
                  className="block px-4 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  Inventaire
                </a>
              </li>
              <li>
                <a 
                  href="/qr-codes" 
                  className="block px-4 py-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                  QR Codes
                </a>
              </li>
            </ul>
          </nav>
        </aside>
        
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
