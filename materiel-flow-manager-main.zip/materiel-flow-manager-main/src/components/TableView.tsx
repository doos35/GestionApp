
import React, { useState } from 'react';
import { MaterialItem } from '@/types';
import QRCodeGenerator from './QRCodeGenerator';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger
} from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  ChevronDown, 
  ChevronRight, 
  Edit, 
  MoreHorizontal, 
  QrCode, 
  Trash, 
  ArrowDownCircle, 
  ArrowUpCircle,
  FolderDown,
  FolderUp 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/components/ui/use-toast';

interface TableViewProps {
  materials: MaterialItem[];
  onEdit: (material: MaterialItem) => void;
  onDelete: (id: string) => void;
  onNestMaterial?: (childId: string, parentId: string) => void;
  onUnnestMaterial?: (childId: string) => void;
}

const TableView: React.FC<TableViewProps> = ({ 
  materials, 
  onEdit, 
  onDelete,
  onNestMaterial,
  onUnnestMaterial
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialItem | null>(null);
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
  
  // Organiser les matériels en hiérarchie
  const getChildMaterials = (parentId: string | null): MaterialItem[] => {
    return materials.filter(m => m.location.parentId === parentId);
  };
  
  // Filtrer les matériels de premier niveau et les filtrer par recherche
  const filteredMaterials = materials
    .filter(material => 
      material.location.parentId === null &&
      (material.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
       material.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
       material.type.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  
  const handleGenerateQR = (material: MaterialItem) => {
    setSelectedMaterial(material);
    setShowQRDialog(true);
  };

  const toggleRowExpand = (id: string) => {
    setExpandedRows(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const isRowExpanded = (id: string) => {
    return expandedRows[id] || false;
  };

  const handleNestMaterial = (childId: string, parentId: string) => {
    if (onNestMaterial) {
      onNestMaterial(childId, parentId);
      toast({
        title: "Succès",
        description: "Élément placé dans le conteneur.",
      });
    }
  };

  const handleUnnestMaterial = (childId: string) => {
    if (onUnnestMaterial) {
      onUnnestMaterial(childId);
      toast({
        title: "Succès",
        description: "Élément retiré du conteneur.",
      });
    }
  };

  const getContainerOptions = (material: MaterialItem) => {
    // Récupérer tous les conteneurs disponibles sauf celui actuel et ses parents
    // (pour éviter les boucles d'imbrication)
    return materials.filter(m => 
      m.type === 'container' && 
      m.id !== material.id &&
      m.location.parentId !== material.id
    );
  };
  
  const renderMaterialRow = (material: MaterialItem, level = 0) => {
    const children = getChildMaterials(material.id);
    const hasChildren = children.length > 0;
    const isExpanded = isRowExpanded(material.id);
    const containerOptions = getContainerOptions(material);
    const canBeContainer = material.type === 'container';
    
    return (
      <React.Fragment key={material.id}>
        <TableRow className={cn(
          "transition-colors hover:bg-muted/50",
          level > 0 && "bg-muted/20"
        )}>
          <TableCell className="font-mono text-xs" style={{ paddingLeft: `${level * 2 + 1}rem` }}>
            <div className="flex items-center space-x-2">
              {hasChildren ? (
                <button onClick={() => toggleRowExpand(material.id)} className="focus:outline-none">
                  {isExpanded ? (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>
              ) : (
                <span className="w-4" />
              )}
              {material.id}
            </div>
          </TableCell>
          <TableCell className="font-medium">{material.designation}</TableCell>
          <TableCell>
            <span className={`px-2 py-1 rounded-full text-xs font-medium
              ${material.type === 'equipment' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' : ''}
              ${material.type === 'container' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100' : ''}
              ${material.type === 'cable' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' : ''}
            `}>
              {material.type}
            </span>
          </TableCell>
          <TableCell>
            {material.physicalAttributes.width && `L: ${material.physicalAttributes.width} `}
            {material.physicalAttributes.height && `H: ${material.physicalAttributes.height} `}
            {material.physicalAttributes.weight && `P: ${material.physicalAttributes.weight}kg`}
          </TableCell>
          <TableCell>
            {material.location.parentId ? (
              <span className="flex items-center">
                {materials.find(m => m.id === material.location.parentId)?.designation || material.location.parentId}
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-6 w-6 ml-1"
                  onClick={() => handleUnnestMaterial(material.id)}
                  title="Retirer du conteneur"
                >
                  <ArrowUpCircle size={14} />
                </Button>
              </span>
            ) : (
              'N/A'
            )}
          </TableCell>
          <TableCell className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal size={16} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(material)}>
                  <Edit size={16} className="mr-2" />
                  Modifier
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleGenerateQR(material)}>
                  <QrCode size={16} className="mr-2" />
                  QR Code
                </DropdownMenuItem>

                {/* Sous-menu pour l'imbrication */}
                {onNestMaterial && material.location.parentId === null && containerOptions.length > 0 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuSub>
                      <DropdownMenuSubTrigger>
                        <FolderDown size={16} className="mr-2" />
                        Placer dans conteneur
                      </DropdownMenuSubTrigger>
                      <DropdownMenuSubContent>
                        {containerOptions.map(container => (
                          <DropdownMenuItem 
                            key={container.id}
                            onClick={() => handleNestMaterial(material.id, container.id)}
                          >
                            {container.designation}
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuSubContent>
                    </DropdownMenuSub>
                  </>
                )}

                {material.location.parentId && onUnnestMaterial && (
                  <DropdownMenuItem onClick={() => handleUnnestMaterial(material.id)}>
                    <FolderUp size={16} className="mr-2" />
                    Retirer du conteneur
                  </DropdownMenuItem>
                )}

                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onDelete(material.id)}
                  className="text-red-600 dark:text-red-400"
                >
                  <Trash size={16} className="mr-2" />
                  Supprimer
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        </TableRow>

        {/* Render children recursively if expanded */}
        {isExpanded && hasChildren && children.map(child => renderMaterialRow(child, level + 1))}
      </React.Fragment>
    );
  };
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Liste du matériel</h2>
        <div className="flex items-center space-x-2">
          <Input
            placeholder="Rechercher..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-64"
          />
        </div>
      </div>
      
      <div className="border rounded-md overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>Désignation</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="w-[150px]">Dimensions</TableHead>
              <TableHead className="w-[150px]">Emplacement</TableHead>
              <TableHead className="w-[80px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMaterials.map(material => renderMaterialRow(material))}
            {filteredMaterials.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-4 text-gray-500">
                  Aucun élément trouvé
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>QR Code pour {selectedMaterial?.designation}</DialogTitle>
          </DialogHeader>
          {selectedMaterial && <QRCodeGenerator material={selectedMaterial} />}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TableView;

