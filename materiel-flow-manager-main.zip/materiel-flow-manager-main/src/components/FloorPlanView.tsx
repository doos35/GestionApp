
import React, { useState, useRef, useEffect } from 'react';
import { MaterialItem } from '@/types';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Grid, 
  Move, 
  Zap, 
  Plus, 
  Trash, 
  Edit, 
  Layout, 
  ArrowUpCircle 
} from 'lucide-react';
import MaterialForm from './MaterialForm';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { toast } from '@/components/ui/use-toast';

interface FloorPlanViewProps {
  materials: MaterialItem[];
  onMaterialMove: (id: string, newX: number, newY: number) => void;
  onAddMaterial?: (material: Omit<MaterialItem, 'id' | 'qrData'>) => void;
  onUpdateMaterial?: (material: MaterialItem) => void;
  onDeleteMaterial?: (id: string) => void;
  backgroundImage?: string;
}

const FloorPlanView: React.FC<FloorPlanViewProps> = ({
  materials,
  onMaterialMove,
  onAddMaterial,
  onUpdateMaterial,
  onDeleteMaterial,
  backgroundImage,
}) => {
  const [showGrid, setShowGrid] = useState(true);
  const [scale, setScale] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editMaterial, setEditMaterial] = useState<MaterialItem | null>(null);
  const [contextMenuPosition, setContextMenuPosition] = useState<{ x: number, y: number } | null>(null);
  const [showContextMenu, setShowContextMenu] = useState(false);
  
  const canvasRef = useRef<HTMLDivElement>(null);
  const dragStartPosRef = useRef<{ x: number; y: number } | null>(null);
  
  const handleZoomIn = () => {
    setScale(prev => Math.min(prev + 0.1, 2.5));
  };
  
  const handleZoomOut = () => {
    setScale(prev => Math.max(prev - 0.1, 0.5));
  };
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'g' && e.shiftKey) {
        setShowGrid(prev => !prev);
      }
      
      if (selectedItem && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        const material = materials.find(m => m.id === selectedItem);
        if (!material) return;
        
        const { x, y } = material.location.coordinates;
        let newX = x;
        let newY = y;
        
        const step = e.shiftKey ? 10 : 1;
        
        switch (e.key) {
          case 'ArrowUp':
            newY -= step;
            break;
          case 'ArrowDown':
            newY += step;
            break;
          case 'ArrowLeft':
            newX -= step;
            break;
          case 'ArrowRight':
            newX += step;
            break;
        }
        
        onMaterialMove(selectedItem, newX, newY);
        e.preventDefault();
      }

      // Delete avec touche delete ou backspace
      if (selectedItem && (e.key === 'Delete' || e.key === 'Backspace') && onDeleteMaterial) {
        if (window.confirm('Êtes-vous sûr de vouloir supprimer cet élément ?')) {
          onDeleteMaterial(selectedItem);
          setSelectedItem(null);
        }
        e.preventDefault();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedItem, materials, onMaterialMove, onDeleteMaterial]);
  
  const handleMouseDown = (id: string, e: React.MouseEvent) => {
    if (e.button === 2) {  // Clic droit pour le menu contextuel
      e.preventDefault();
      setSelectedItem(id);
      
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      
      setContextMenuPosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      
      setShowContextMenu(true);
      return;
    }
    
    setIsDragging(true);
    setSelectedItem(id);
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    dragStartPosRef.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
    
    e.stopPropagation();
  };
  
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !selectedItem || !dragStartPosRef.current) return;
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const currentX = e.clientX - rect.left;
    const currentY = e.clientY - rect.top;
    
    const material = materials.find(m => m.id === selectedItem);
    if (!material) return;
    
    const snapTolerance = 10;
    const gridSize = 20;
    
    let newX = material.location.coordinates.x + (currentX - dragStartPosRef.current.x) / scale;
    let newY = material.location.coordinates.y + (currentY - dragStartPosRef.current.y) / scale;
    
    if (showGrid) {
      const snapX = Math.round(newX / gridSize) * gridSize;
      const snapY = Math.round(newY / gridSize) * gridSize;
      
      if (Math.abs(newX - snapX) < snapTolerance) newX = snapX;
      if (Math.abs(newY - snapY) < snapTolerance) newY = snapY;
    }
    
    // Vérifier s'il y a un conteneur sous le curseur pour l'imbrication
    const containerId = findContainerAt(newX, newY, material.id);
    if (containerId) {
      // Surligner visuellement le conteneur potentiel
      // (géré par les classes CSS dans le rendu)
    }
    
    onMaterialMove(selectedItem, newX, newY);
    
    dragStartPosRef.current = { x: currentX, y: currentY };
  };
  
  const handleMouseUp = (e: React.MouseEvent) => {
    if (isDragging && selectedItem) {
      const material = materials.find(m => m.id === selectedItem);
      if (!material) return;
      
      const { x, y } = material.location.coordinates;
      
      // Vérifier s'il y a un conteneur à cet emplacement
      const containerId = findContainerAt(x, y, material.id);
      
      if (containerId && onUpdateMaterial) {
        // Imbriquer l'élément dans le conteneur
        const updatedMaterial = {
          ...material,
          location: {
            ...material.location,
            parentId: containerId
          }
        };
        
        onUpdateMaterial(updatedMaterial);
        toast({
          title: "Imbrication réussie",
          description: `${material.designation} a été placé dans le conteneur.`,
        });
      }
    }
    
    setIsDragging(false);
    dragStartPosRef.current = null;
    
    // Fermer le menu contextuel si on clique ailleurs
    if (e.button === 0 && showContextMenu) {
      setShowContextMenu(false);
    }
  };
  
  const findContainerAt = (x: number, y: number, excludeId: string): string | null => {
    // Trouver un conteneur à la position donnée
    for (const material of materials) {
      if (material.id === excludeId || material.type !== 'container') continue;
      
      // Vérifier si les coordonnées sont dans ce conteneur
      const { width, height } = getMaterialSize(material);
      const mx = material.location.coordinates.x;
      const my = material.location.coordinates.y;
      
      if (x >= mx && x <= mx + width && y >= my && y <= my + height) {
        return material.id;
      }
    }
    
    return null;
  };
  
  const handleCanvasClick = (e: React.MouseEvent) => {
    // Désélectionner l'élément actuel si on clique ailleurs
    if (e.target === e.currentTarget) {
      setSelectedItem(null);
      setShowContextMenu(false);
    }

    // Ajouter un nouvel élément à la position du clic si le bouton d'ajout est actif
    if (e.altKey && e.button === 0 && onAddMaterial) {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (!rect) return;
      
      const x = (e.clientX - rect.left) / scale;
      const y = (e.clientY - rect.top) / scale;
      
      // Ouvrir le formulaire d'ajout avec des coordonnées prédéfinies
      setIsAddDialogOpen(true);
      
      // Stocker temporairement les coordonnées pour le nouveau matériel
      // (utilisé dans handleAddMaterial)
      dragStartPosRef.current = { x, y };
    }
  };

  const handleAddMaterial = (data: Omit<MaterialItem, 'id' | 'qrData'>) => {
    if (onAddMaterial && dragStartPosRef.current) {
      const newMaterial = {
        ...data,
        location: {
          ...data.location,
          coordinates: { 
            x: dragStartPosRef.current.x, 
            y: dragStartPosRef.current.y 
          }
        }
      };
      
      onAddMaterial(newMaterial);
      setIsAddDialogOpen(false);
    }
  };

  const handleEditMaterial = () => {
    if (selectedItem) {
      const material = materials.find(m => m.id === selectedItem);
      if (material) {
        setEditMaterial(material);
        setIsEditDialogOpen(true);
        setShowContextMenu(false);
      }
    }
  };

  const handleDeleteMaterial = () => {
    if (selectedItem && onDeleteMaterial) {
      if (window.confirm('Êtes-vous sûr de vouloir supprimer cet élément ?')) {
        onDeleteMaterial(selectedItem);
        setSelectedItem(null);
        setShowContextMenu(false);
      }
    }
  };

  const handleUpdateMaterial = (data: Omit<MaterialItem, 'id' | 'qrData'>) => {
    if (editMaterial && onUpdateMaterial) {
      const updatedMaterial = {
        ...editMaterial,
        designation: data.designation,
        type: data.type,
        physicalAttributes: data.physicalAttributes
      };
      
      onUpdateMaterial(updatedMaterial);
      setIsEditDialogOpen(false);
      setEditMaterial(null);
    }
  };

  const handleRemoveFromParent = () => {
    if (selectedItem) {
      const material = materials.find(m => m.id === selectedItem);
      if (material && material.location.parentId && onUpdateMaterial) {
        const updatedMaterial = {
          ...material,
          location: {
            ...material.location,
            parentId: null
          }
        };
        
        onUpdateMaterial(updatedMaterial);
        setShowContextMenu(false);
        
        toast({
          title: "Succès",
          description: `${material.designation} a été retiré du conteneur.`,
        });
      }
    }
  };
  
  const getMaterialSize = (material: MaterialItem) => {
    const parentScale = material.location.parentId ? 0.8 : 1;
    switch (material.type) {
      case 'equipment':
        return { 
          width: 80 * parentScale, 
          height: 40 * parentScale 
        };
      case 'container':
        return { 
          width: 120 * parentScale, 
          height: 80 * parentScale 
        };
      case 'cable':
        return { 
          width: 30 * parentScale, 
          height: 10 * parentScale 
        };
      default:
        return { 
          width: 60 * parentScale, 
          height: 30 * parentScale 
        };
    }
  };
  
  const getMaterialColor = (material: MaterialItem) => {
    switch (material.type) {
      case 'equipment':
        return 'bg-blue-500 dark:bg-blue-700';
      case 'container':
        return 'bg-purple-500 dark:bg-purple-700';
      case 'cable':
        return 'bg-green-500 dark:bg-green-700';
      default:
        return 'bg-gray-500 dark:bg-gray-700';
    }
  };

  const canReceiveChildren = (material: MaterialItem) => {
    return material.type === 'container';
  };

  // Pour les événements de clic droit
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };
  
  return (
    <div className="flex flex-col h-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Plan d'étage</h2>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setShowGrid(!showGrid)}
            className={showGrid ? 'bg-gray-200 dark:bg-gray-700' : ''}
          >
            <Grid size={18} />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setIsAddDialogOpen(true)}
          >
            <Plus size={18} className="mr-1" />
            Ajouter
          </Button>
          <Button variant="outline" size="icon" onClick={handleZoomOut}>
            <span className="text-xl">−</span>
          </Button>
          <span className="text-sm w-12 text-center">
            {Math.round(scale * 100)}%
          </span>
          <Button variant="outline" size="icon" onClick={handleZoomIn}>
            <span className="text-xl">+</span>
          </Button>
        </div>
      </div>
      
      <Separator className="mb-4" />
      
      <div className="flex-1 overflow-auto bg-canvas-bg rounded-lg border">
        <div
          ref={canvasRef}
          className="relative w-full h-full min-h-[600px] overflow-auto"
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onClick={handleCanvasClick}
          onContextMenu={handleContextMenu}
        >
          {showGrid && (
            <div 
              className="absolute inset-0 grid" 
              style={{
                backgroundSize: `${20 * scale}px ${20 * scale}px`,
                backgroundImage: 'linear-gradient(to right, hsla(var(--grid-color) / 0.2) 1px, transparent 1px), linear-gradient(to bottom, hsla(var(--grid-color) / 0.2) 1px, transparent 1px)',
                transform: `scale(${scale})`,
                transformOrigin: '0 0'
              }}
            />
          )}
          
          {backgroundImage && (
            <div
              className="absolute inset-0 bg-center bg-no-repeat pointer-events-none"
              style={{
                backgroundImage: `url(${backgroundImage})`,
                backgroundSize: 'contain',
                transform: `scale(${scale})`,
                transformOrigin: '0 0'
              }}
            />
          )}
          
          <div 
            className="absolute inset-0" 
            style={{ 
              transform: `scale(${scale})`,
              transformOrigin: '0 0'
            }}
          >
            {materials.map((material) => {
              const { width, height } = getMaterialSize(material);
              const color = getMaterialColor(material);
              const { x, y } = material.location.coordinates;
              
              if (material.location.parentId) return null;
              
              return (
                <div
                  key={material.id}
                  className={`absolute flex flex-col items-center justify-center cursor-move select-none shadow-md border overflow-hidden
                    ${color}
                    ${selectedItem === material.id ? 'ring-2 ring-offset-2 ring-blue-500 z-10' : ''}
                    ${canReceiveChildren(material) ? 'border-dashed' : ''}
                    ${isDragging && findContainerAt(x, y, selectedItem || '') === material.id ? 'ring-2 ring-yellow-500' : ''}
                  `}
                  style={{
                    width: `${width}px`,
                    height: `${height}px`,
                    left: `${x}px`,
                    top: `${y}px`,
                    borderRadius: '4px',
                  }}
                  onMouseDown={(e) => handleMouseDown(material.id, e)}
                >
                  <div className="text-white text-xs font-medium truncate px-1">
                    {material.designation}
                  </div>
                  
                  {canReceiveChildren(material) && (
                    <div className="flex flex-wrap gap-1 p-1">
                      {materials
                        .filter(m => m.location.parentId === material.id)
                        .map(childMaterial => {
                          const childSize = getMaterialSize(childMaterial);
                          const childColor = getMaterialColor(childMaterial);
                          
                          return (
                            <div
                              key={childMaterial.id}
                              className={`flex items-center justify-center ${childColor} rounded cursor-pointer text-[8px] p-0.5
                                ${selectedItem === childMaterial.id ? 'ring-1 ring-blue-500' : ''}
                              `}
                              style={{
                                width: `${childSize.width}px`,
                                height: `${childSize.height}px`,
                              }}
                              onMouseDown={(e) => {
                                e.stopPropagation();
                                handleMouseDown(childMaterial.id, e);
                              }}
                            >
                              {childMaterial.designation}
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Menu contextuel */}
          {showContextMenu && contextMenuPosition && (
            <div 
              className="absolute bg-white dark:bg-gray-800 rounded-md shadow-lg z-50 border"
              style={{
                left: `${contextMenuPosition.x}px`,
                top: `${contextMenuPosition.y}px`,
              }}
            >
              <div className="py-1">
                <button 
                  onClick={handleEditMaterial}
                  className="flex items-center w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <Edit size={16} className="mr-2" /> Modifier
                </button>
                <button 
                  onClick={handleDeleteMaterial}
                  className="flex items-center w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 text-red-600 dark:text-red-400"
                >
                  <Trash size={16} className="mr-2" /> Supprimer
                </button>
                
                {selectedItem && materials.find(m => m.id === selectedItem)?.location.parentId && (
                  <button 
                    onClick={handleRemoveFromParent}
                    className="flex items-center w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <ArrowUpCircle size={16} className="mr-2" /> Retirer du conteneur
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-4 p-3 border rounded-md bg-gray-50 dark:bg-gray-800 text-xs">
        <div className="font-semibold mb-1">Raccourcis clavier:</div>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center">
            <kbd className="px-1 py-0.5 bg-gray-200 dark:bg-gray-700 rounded border">Shift+G</kbd>
            <span className="ml-2">Afficher/masquer la grille</span>
          </div>
          <div className="flex items-center">
            <kbd className="px-1 py-0.5 bg-gray-200 dark:bg-gray-700 rounded border">Flèches</kbd>
            <span className="ml-2">Déplacer élément sélectionné</span>
          </div>
          <div className="flex items-center">
            <kbd className="px-1 py-0.5 bg-gray-200 dark:bg-gray-700 rounded border">Alt+Clic</kbd>
            <span className="ml-2">Ajouter un élément</span>
          </div>
          <div className="flex items-center">
            <kbd className="px-1 py-0.5 bg-gray-200 dark:bg-gray-700 rounded border">Delete</kbd>
            <span className="ml-2">Supprimer élément sélectionné</span>
          </div>
        </div>
      </div>

      {/* Formulaires */}
      <MaterialForm
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onSubmit={handleAddMaterial}
      />
      
      <MaterialForm
        isOpen={isEditDialogOpen}
        onClose={() => setIsEditDialogOpen(false)}
        onSubmit={handleUpdateMaterial}
        initialData={editMaterial || undefined}
      />
    </div>
  );
};

export default FloorPlanView;

