
import React from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MaterialItem } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

interface MaterialFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<MaterialItem, 'id' | 'qrData'>) => void;
  initialData?: MaterialItem;
}

const MaterialForm: React.FC<MaterialFormProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData
}) => {
  const { register, handleSubmit, reset } = useForm({
    defaultValues: {
      designation: initialData?.designation || '',
      type: initialData?.type || 'equipment',
      width: initialData?.physicalAttributes.width || '',
      height: initialData?.physicalAttributes.height || '',
      weight: initialData?.physicalAttributes.weight?.toString() || '',
    }
  });

  const onFormSubmit = (data: any) => {
    onSubmit({
      type: data.type,
      designation: data.designation,
      physicalAttributes: {
        width: data.width,
        height: data.height,
        weight: parseFloat(data.weight) || 0,
      },
      location: {
        parentId: null,
        coordinates: { x: 100, y: 100 }
      },
    });
    reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{initialData ? 'Modifier' : 'Ajouter'} un bloc</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Désignation</label>
            <Input {...register('designation')} required />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Type</label>
            <Select 
              {...register('type')} 
              defaultValue={initialData?.type || 'equipment'}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="equipment">Équipement</SelectItem>
                <SelectItem value="container">Conteneur</SelectItem>
                <SelectItem value="cable">Câble</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Largeur</label>
              <Input {...register('width')} placeholder="19&quot;" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Hauteur</label>
              <Input {...register('height')} placeholder="2U" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Poids (kg)</label>
              <Input {...register('weight')} type="number" step="0.1" />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button type="submit">
              {initialData ? 'Mettre à jour' : 'Ajouter'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MaterialForm;
