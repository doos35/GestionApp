
import React, { useState, useRef, useEffect } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { QRCodeData } from '@/types';

interface QRCodeScannerProps {
  onScan: (data: QRCodeData) => void;
  visualFeedback?: 'glow' | 'highlight' | 'none';
}

const QRCodeScanner: React.FC<QRCodeScannerProps> = ({ 
  onScan, 
  visualFeedback = 'glow'
}) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastScanned, setLastScanned] = useState<QRCodeData | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
        setError(null);
        
        // Start scanning loop
        animationRef.current = requestAnimationFrame(scanQRCode);
      }
    } catch (err) {
      setError('Impossible d\'accéder à la caméra. Vérifiez vos permissions.');
      console.error('Camera error:', err);
    }
  };
  
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    
    setIsCameraActive(false);
    
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);
  
  const scanQRCode = () => {
    if (!isCameraActive || !videoRef.current || !canvasRef.current) {
      return;
    }
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      canvas.height = video.videoHeight;
      canvas.width = video.videoWidth;
      
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // In a real app, you would use a QR code library here
      // For demonstration purposes, let's simulate a scan after a short delay
      // In production, use something like jsQR or ZXing to decode the image
      
      // Simulated scan every 3 seconds for demo
      setTimeout(() => {
        // Simulate processing the QR code data
        const processQR = (data: string): QRCodeData => {
          const parts = data.split('|');
          const idPart = parts.find(p => p.startsWith('MAT:'))?.split(':')[1] || '';
          const locationPart = parts.find(p => p.startsWith('LOC:'))?.split(':')[1] || '';
          const typePart = parts.find(p => p.startsWith('TYPE:'))?.split(':')[1] || '';
          
          return {
            id: idPart,
            location: locationPart,
            itemType: typePart
          };
        };
        
        // Simulated QR code data
        const simulatedData = "MAT:EQUIP-001|LOC:null|TYPE:equipment";
        const qrData = processQR(simulatedData);
        
        setLastScanned(qrData);
        onScan(qrData);
      }, 3000);
    }
    
    animationRef.current = requestAnimationFrame(scanQRCode);
  };
  
  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Scanner QR Code</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertTitle>Erreur</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        <div className="relative">
          <video
            ref={videoRef}
            className={`w-full rounded-md ${isCameraActive ? 'block' : 'hidden'}`}
            autoPlay
            playsInline
            muted
          />
          <canvas
            ref={canvasRef}
            className="absolute top-0 left-0 w-full h-full hidden"
          />
          
          {!isCameraActive && (
            <div className="h-64 bg-gray-200 dark:bg-gray-800 rounded-md flex items-center justify-center">
              <p className="text-gray-500 dark:text-gray-400">
                Caméra désactivée
              </p>
            </div>
          )}
          
          {isCameraActive && (
            <div className={`absolute inset-0 border-2 rounded-md pointer-events-none
              ${visualFeedback === 'glow' ? 'animate-pulse-highlight' : ''}
              ${visualFeedback === 'highlight' ? 'border-blue-500' : 'border-transparent'}`}
            >
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1/2 h-1/2 border-2 border-white/30"></div>
            </div>
          )}
        </div>
        
        {lastScanned && (
          <div className="p-3 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100 rounded-md">
            <div className="font-semibold">Dernier scan:</div>
            <div className="text-sm">
              ID: {lastScanned.id}<br />
              Type: {lastScanned.itemType}<br />
              Emplacement: {lastScanned.location}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button 
          onClick={isCameraActive ? stopCamera : startCamera}
          variant={isCameraActive ? "destructive" : "default"}
          className="w-full"
        >
          {isCameraActive ? "Arrêter la caméra" : "Démarrer la caméra"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default QRCodeScanner;
