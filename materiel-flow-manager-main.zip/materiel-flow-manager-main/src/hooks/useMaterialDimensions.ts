
import { useState, useCallback } from 'react';
import { MaterialItem } from '@/types';

export const useMaterialDimensions = (initialMaterial: MaterialItem) => {
  const [dimensions, setDimensions] = useState({
    width: initialMaterial.physicalAttributes.width || '',
    height: initialMaterial.physicalAttributes.height || '',
    weight: initialMaterial.physicalAttributes.weight || 0,
  });

  const updateDimension = useCallback((dimension: 'width' | 'height' | 'weight', value: string | number) => {
    setDimensions(prev => ({
      ...prev,
      [dimension]: value,
    }));
  }, []);

  return {
    dimensions,
    updateDimension,
    getDimensionsObject: () => ({
      width: dimensions.width || undefined,
      height: dimensions.height || undefined,
      weight: dimensions.weight || undefined,
    }),
  };
};
